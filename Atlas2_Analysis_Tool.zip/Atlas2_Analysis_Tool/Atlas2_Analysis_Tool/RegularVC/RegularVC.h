//
//  OC_Regular.h
//  Atlas2_Analysis_Tool
//
//  Created by ciwei luo on 2021/6/22.
//  Copyright © 2021 Suncode. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "ExtensionConst.h"
NS_ASSUME_NONNULL_BEGIN

@interface RegularVC : NSViewController

@end

NS_ASSUME_NONNULL_END
