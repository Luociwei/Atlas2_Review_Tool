//
//  RegularTabVC.h
//  Atlas2_Review_Tool
//
//  Created by ciwei luo on 2021/8/12.
//  Copyright © 2021 Suncode. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "ExtensionConst.h"
NS_ASSUME_NONNULL_BEGIN

@interface RegularTabVC : TabViewController

@end

NS_ASSUME_NONNULL_END
