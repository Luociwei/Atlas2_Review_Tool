//
//  CycleTimeModel.m
//  Atlas2_Review_Tool
//
//  Created by ciwei luo on 2021/8/13.
//  Copyright © 2021 Suncode. All rights reserved.
//

#import "CycleTimeModel.h"

@implementation CycleTimeModel

@end
