Atlas2_Review_Tool v1.3

others function: 
.select the row  and double click will show record/uart or lua function UI.
.hit 'command + f' on your keyboard to search on the text view.
.select the rows and hit the delete key on your keyboard will delete the test log. the password is yyyymm .
