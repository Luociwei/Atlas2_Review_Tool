//
//  FileDragView.h
//  DragDropDemo
//
//  Created by Louis Luo on 2020/6/24.
//  Copyright © 2020 Suncode. All rights reserved.

#import <Cocoa/Cocoa.h>

@interface FileDragView : NSTextField

@end
