#ifndef ATILUALOGGING_H
#define ATILUALOGGING_H

void ati_print_buffer_error(const char *format, ...);
void ati_print_length(const char *str, int length);

#endif
