//
//  IAFileHandle.m
//  FCTFixture
//
//  Created by RyanGao on 12/9/16.
//  Copyright © 2016 IvanGan. All rights reserved.
//

#import "IAFileHandle.h"

@implementation IAFileHandle

+(void)Test2{
    NSLog(@"00000");
}

@end
