//
//  IAFileHandle.h
//  FCTFixture
//
//  Created by RyanGao on 12/9/16.
//  Copyright © 2016 IvanGan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IAFileHandle : NSFileHandle
+(void)Test2;

@end
