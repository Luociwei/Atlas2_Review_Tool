# Atlas2FixturePlugin
Fixture plugin for iPx DFU and SoC
