//
//  FixtureBundle.h
//  FixtureBundle
//
//  Created by eyen on 9/9/16.
//  Copyright © 2016 Apple. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreTestFoundation/CoreTestFoundation.h>

@interface FixtureBundle : CTPluginBaseFactory <CTPluginFactory>

@end
