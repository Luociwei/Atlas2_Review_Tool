

tolua=/usr/local/lib/tolua++

$tolua -o RPC_Client_G_1_lua.mm RPC_Client_G_1.pkg
