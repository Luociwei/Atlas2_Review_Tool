#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @Time  : 2021/12/11 1:44 PM
# @Author: Ci-wei
# @File  : zmq_socket.py
import re
import json

try:
    import zmq
except Exception as e:
    print('import zmq error:', e)


# import
class ZmqMsg:
    def __init__(self, msg):
        self.name = ''
        self.event = ''
        self.params = []
        if len(msg):
            msg_dict = json.loads(msg)
            if msg_dict:
                self.name = msg_dict['name']
                self.event = msg_dict['event']
                self.params = msg_dict['params']
            # params_pattern1 = re.compile(r'params\s+=\s+\(\s+([\s\S]+)\s+\);')
            # params_results1 = params_pattern1.findall(msg)
            # if len(params_results1):
            #     params_pattern2 = re.compile(r'[\"](.+)[\"]')
            #     params_results2 = params_pattern2.findall(params_results1[0])
            #     self.params = params_results2
            #
            # title_pattern = re.compile(r'title\s+=\s+(\w+);')
            # title_results = title_pattern.findall(msg)
            # if len(title_results):
            #     self.title = title_results[0]
            #
            # event_pattern = re.compile(r'event\s+=\s+(\w+);')
            # event_results = event_pattern.findall(msg)
            # if len(event_results):
            #     self.event = event_results[0]


class ZmqClient(object):
    def __init__(self, url):
        context = zmq.Context()
        socket = context.socket(zmq.REP)
        socket.setsockopt(zmq.LINGER, 0)
        # "tcp://127.0.0.1:3100"
        self.url = url
        socket.bind(url)
        self.socket = socket

    def send(self, cmd):

        if type(cmd) == type([]) or type(cmd) == type({}):
            json_cmd = json.dumps(cmd)
            # print('json_cmd:', json_cmd)
            self.socket.send(json_cmd.encode('ascii'))
        elif type(cmd) == type(''):
            print(cmd)
            self.socket.send(cmd.encode('ascii'))
        else:
            pass

    def recv(self):
        r = self.socket.recv()
        return r.decode('utf-8')


if __name__ == '__main__':
    pass
    # print('ss')
    # str = '"{\n    event = GenerateClick;\n    params =     (\n        \"/Users/gdlocal/Library/Logs/Atlas/unit-archive/\"\n    );\n    title = AtlasLog;\n}"'
    # zmq_msg = ZmqMsg(str)
    #
    # print(f'zmq_msg.event:{zmq_msg.event}')
    # print(f'zmq_msg.title:{zmq_msg.title}')
    # print(f'zmq_msg.params:{zmq_msg.params}')
